<?php

namespace Database\Factories;

use App\Models\Movie;
use Illuminate\Database\Eloquent\Factories\Factory;

class MovieFactory extends Factory
{   
    protected $model = Movie::class;
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition()
    {
        return [
            'title'=>$this->faker->realText($maxNbChars = 20, $indexSize = 2),
            'description'=>$this->faker->realText($maxNbChars = 60, $indexSize = 2),
            'duration'=>$this->faker->numberBetween($min = 60, $max = 220),
            'genre_id'=>$this->faker->numberBetween($min = 1, $max = 20),
            'director_id'=>$this->faker->numberBetween($min = 1, $max = 20),
            'img'=>$this->faker->imageUrl($width=320, $height=540, 'movie')
        ];
    }
}
