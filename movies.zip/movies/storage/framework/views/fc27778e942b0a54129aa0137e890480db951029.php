<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <script src="https://kit.fontawesome.com/85b665b81a.js" crossorigin="anonymous"></script>
        <title>Videoteka</title>
</head>

<body>
    <style>
        body {
            background-image: url('https://img.freepik.com/free-photo/popcorn-juice-movie-night_23-2148470131.jpg');
            font-family: 'Trebuchet MS', sans-serif;
        }
    </style>
    
    <div class='container'>
        <div class='row mt-2'>
            <div class='col-12'>
                
                <a class="navbar-brand" href="index.php"> </a>
                <h1 class='text-center text-black' style="background-color:White;"> 
                <i class="fa-solid fa-film fa-sm fa-beat"></i>
                Filmovi u ponudi
                <i class="fa-solid fa-film fa-sm fa-beat"></i></h1>
                
            </div>
        </div>
        <?php $__currentLoopData = $chunks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row mt-5 d-flex justify-content-center">
            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           
            <div class="col-3 bg-light mr-5 pt-2" align="center">
                <img src="<?php echo e($movie['img']); ?>" width="80" height="120">
                <h4><?php echo e($movie['title']); ?></h4>

                <a href="/movie/<?php echo e($movie->id); ?>">
                    <button class=" btn form-control btn-secondary mb-2" style="background-color:Tomato;">Izmeni</button>
                </a>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    
</body>

</html><?php /**PATH C:\Users\Andjelitis\Desktop\movies\resources\views/home.blade.php ENDPATH**/ ?>