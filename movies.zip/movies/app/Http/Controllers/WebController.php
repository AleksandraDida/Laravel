<?php

namespace App\Http\Controllers;
use App\Models\Movie;
use App\Models\Genre;
use App\Models\Director;
use Illuminate\Http\Request;

class WebController extends Controller
{
    public function all(){
        $movies=Movie::all();
        $response=[];
        foreach ($movies as $movie) {
           $response[]=$movie;
        }
        return view('home',["chunks"=>array_chunk($response,3)]);
       
    }
    public function one($id){
        $movie=Movie::find($id);
        $genres=Genre::all();
        $directors=Director::all();
        return view('edit',['movie'=>$movie,'genres'=>$genres,'directors'=>$directors]);
       
    }
    public function update(Request $request, $id){
        $movie=Movie::find($id);
        if(isset($_POST["delete"])){
            $movie->delete();
            
        }else{
            if(isset($request->title)){
                $movie->title=$request->title;
            }
            if(isset($request->description)){
                $movie->description=$request->description;
            }
            if(isset($request->genre_id)){
                $movie->genre_id=$request->genre_id;
            }
            if(isset($request->director_id)){
                $movie->director_id=$request->director_id;
            }
            if(isset($request->duration)){
                $movie->duration=$request->duration;
            }
            $movie->save();
        }
        return redirect('/');
    }
}