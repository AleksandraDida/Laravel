<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"
        integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <title>Film</title>
</head>

<body>
    <style>
        body {
            background-image: url('https://img.freepik.com/free-photo/popcorn-juice-movie-night_23-2148470131.jpg');
            font-family: 'Trebuchet MS', sans-serif;
        }
    </style>
    <div class='container'>
        <div class='row mt-2'>
            <div class='col-2'>
                <a href="/">
                    <button class='btn btn-secondary' style="background-color:black;">Vrati se nazad</button>
                </a>
            </div>
        </div>
        <div class='row mt-2'>
            <div class='col-12'>
                <h1 class='text-center text-black' style="background-color:White;">{{$movie->title}}</h1>
            </div>
        </div>
        <div class='row mt-2 d-flex justify-content-center'>
            <div class='col-8'>
                <form class='bg-light pt-2 pb-2 pl-2 pr-2' action="/movie/{{$movie->id}}" method="post">
                    <input type="hidden" name="_token" value="{{ csrf_token() }}">
                    <label>Naziv filma</label>
                    <input type="text" name='title' required class='form-control' value='{{$movie->title}}'>
                    <label>Trajanje filma</label>
                    <input type="number" name='pages' required class='form-control' value='{{$movie->duration}}'>
                    <label>Režiser</label>
                    <select name='director_id' required class='form-control'>
                        @foreach($directors as $director)
                        <option value="{{$director->id}}" {{($movie->director->id==$director->id)?'selected':''}}>
                            {{$director->first_name.' '.$director->last_name}}
                        </option>
                        @endforeach
                    </select>
                    <label>Žanr</label>
                    <select name='genre_id' required class='form-control'>
                        @foreach($genres as $genre)
                        <option value="{{$genre->id}}" {{($movie->genre->id==$genre->id)?'selected':''}}>
                        {{$genre->value}}
                        </option>
                        @endforeach
                    </select>
                    <label>Opis</label>
                    <textarea name="description" cols="20" rows="8" class="form-control">{{$movie->description}}
                    </textarea>
                    <button type="submit" class="btn btn-secondary form-control mt-2" >Ažuriraj</button>
                    <button type="submit" name='delete' class="btn btn-danger form-control mt-2" style="background-color:red;">Obriši</button>
                </form>
            </div>
            <div class='col-4'>
                <img src="{{$movie->img}} " width="320" height="540">
            </div>
        </div>
    </div>
</body>

</html>